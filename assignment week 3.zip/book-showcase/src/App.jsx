import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import TopNav from './components/TopNav'
import StateCard from './components/StateCard'
import HomePage from './pages/HomePage'
import BookDetailPage from './pages/BookDetailPage'
import FavoritesPage from './pages/FavoritesPage'
import { readFavoriteIds, FAVORITES_KEY } from './utils/api'

export default function App() {
  const [favoriteIds, setFavoriteIds] = useState(readFavoriteIds)

  // Persist favorites to localStorage whenever they change
  useEffect(() => {
    window.localStorage.setItem(FAVORITES_KEY, JSON.stringify(favoriteIds))
  }, [favoriteIds])

  function handleToggleFavorite(bookId) {
    setFavoriteIds((current) =>
      current.includes(bookId)
        ? current.filter((id) => id !== bookId)
        : [...current, bookId]
    )
  }

  return (
    <BrowserRouter>
      <div className="app-shell">
        <TopNav />
        <Routes>
          <Route
            path="/"
            element={
              <HomePage
                favoriteIds={favoriteIds}
                onToggleFavorite={handleToggleFavorite}
              />
            }
          />
          <Route
            path="/books/:id"
            element={
              <BookDetailPage
                favoriteIds={favoriteIds}
                onToggleFavorite={handleToggleFavorite}
              />
            }
          />
          <Route
            path="/favorites"
            element={
              <FavoritesPage
                favoriteIds={favoriteIds}
                onToggleFavorite={handleToggleFavorite}
              />
            }
          />
          <Route
            path="*"
            element={
              <main className="page-shell">
                <StateCard
                  title="Page not found"
                  message="That route does not exist. Use the navbar to get back on track."
                />
              </main>
            }
          />
        </Routes>
      </div>
    </BrowserRouter>
  )
}
