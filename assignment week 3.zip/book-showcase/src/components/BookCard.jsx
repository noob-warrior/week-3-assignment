import { Link } from 'react-router-dom'
import SmallButton from './SmallButton'

export default function BookCard({ book, isFavorite, onToggleFavorite }) {
  const image = book.cover || 'https://via.placeholder.com/160x230?text=No+Cover'
  const authorText = book.authors.length > 0 ? book.authors.join(', ') : 'Author not listed'

  return (
    <article className="book-card">
      <Link className="book-card-link" to={`/books/${book.id}`}>
        <div className="book-cover-wrap">
          <img className="book-cover" src={image} alt={`${book.title} cover`} />
        </div>
        <div className="book-copy">
          <p className="book-author">{authorText}</p>
          <h3>{book.title}</h3>
        </div>
      </Link>
      <div className="book-card-actions">
        <SmallButton onClick={() => onToggleFavorite(book.id)} active={isFavorite}>
          {isFavorite ? 'Saved' : 'Favorite'}
        </SmallButton>
      </div>
    </article>
  )
}
