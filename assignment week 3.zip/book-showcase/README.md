# Interactive Book Showcase

A React web application to display books from the Google Books API with search, favorites, and detailed views.

## Tech Stack

- **React 18** (with JSX, hooks)
- **React Router DOM v6** (BrowserRouter, Routes, Route, Link, NavLink, useParams)
- **Vite** (development server + build tool)
- **Google Books API** (with Open Library as fallback)

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── BookCard.jsx     # Book card with cover, title, author, favorite button
│   ├── SmallButton.jsx  # Reusable button with active state
│   ├── StateCard.jsx    # Loading / error / empty state card
│   └── TopNav.jsx       # Navigation bar with links to / and /favorites
├── pages/               # Route-level page components
│   ├── HomePage.jsx     # Book list page (/) with search
│   ├── BookDetailPage.jsx  # Book detail page (/books/:id)
│   └── FavoritesPage.jsx   # Favorites page (/favorites)
├── utils/
│   └── api.js           # API fetch functions + localStorage helpers
├── App.jsx              # Root component with BrowserRouter + Routes
├── main.jsx             # ReactDOM.createRoot entry point
└── styles.css           # Global CSS
```

## Features

- **Book List Page (`/`)** — fetches books on mount using `useEffect`, shows loading/error states, real-time search by title or author (case-insensitive)
- **Book Detail Page (`/books/:id`)** — uses `useParams` to fetch a single book by ID, shows full details (title, author, description, cover, publisher, date, pages, categories)
- **Favorites (`/favorites`)** — route that reads favorite IDs from `localStorage`, fetches and displays each book
- **Add to Favorites** — toggle on any card or detail page; state persists via `localStorage`
- **Navbar** — links to `/` and `/favorites` using React Router `NavLink`
- **Reusable components** — `BookCard`, `SmallButton`, `StateCard`, `TopNav`
- **Fallback API** — if Google Books fails, automatically falls back to Open Library

## Getting Started

```bash
npm install
npm run dev
```

Then open [http://localhost:5173](http://localhost:5173).

## API Reference

- **Google Books Search:** `https://www.googleapis.com/books/v1/volumes?q=...`
- **Google Books by ID:** `https://www.googleapis.com/books/v1/volumes/{volumeId}`
- **Open Library (fallback):** `https://openlibrary.org/search.json?q=...`
