export default function StateCard({ title, message, tone = 'info' }) {
  return (
    <div className={`state-card ${tone}`}>
      <h3>{title}</h3>
      <p>{message}</p>
    </div>
  )
}
