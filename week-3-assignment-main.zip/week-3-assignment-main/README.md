just open the file normally.


Project updated and cleaned up for readability.
