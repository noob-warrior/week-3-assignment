import { useState, useEffect } from 'react'
import BookCard from '../components/BookCard'
import StateCard from '../components/StateCard'
import { fetchBookById } from '../utils/api'

export default function FavoritesPage({ favoriteIds, onToggleFavorite }) {
  const [books, setBooks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let isMounted = true

    async function loadFavorites() {
      try {
        setLoading(true)
        setError('')

        if (favoriteIds.length === 0) {
          if (isMounted) setBooks([])
          return
        }

        const responses = await Promise.allSettled(
          favoriteIds.map((bookId) => fetchBookById(bookId))
        )

        const nextBooks = responses
          .filter((r) => r.status === 'fulfilled')
          .map((r) => r.value)

        const rejectedCount = responses.filter((r) => r.status === 'rejected').length

        if (isMounted) {
          setBooks(nextBooks)
          if (rejectedCount > 0) {
            setError('A couple of favorite books did not load, but the rest are shown below.')
          }
        }
      } catch (fetchError) {
        if (isMounted) {
          setError(fetchError.message || 'Something went wrong while loading favorites.')
        }
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    loadFavorites()

    return () => {
      isMounted = false
    }
  }, [favoriteIds])

  return (
    <main className="page-shell">
      <section className="favorites-head">
        <div>
          <p className="eyebrow">Favorites Display</p>
          <h1>Your saved books</h1>
          <p className="muted-copy">
            Favorite IDs are stored in localStorage and the page fetches each book from the API.
          </p>
        </div>
        <div className="favorites-badge">{favoriteIds.length} saved</div>
      </section>

      {loading && <StateCard title="Loading…" message="Finding your favorite books." />}

      {!loading && error && <StateCard title="Heads up" message={error} tone="error" />}

      {!loading && books.length === 0 && (
        <StateCard
          title="No favorites yet"
          message="Open a book detail page or tap the favorite button on a card to save one."
        />
      )}

      {!loading && books.length > 0 && (
        <section className="book-grid">
          {books.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              isFavorite={favoriteIds.includes(book.id)}
              onToggleFavorite={onToggleFavorite}
            />
          ))}
        </section>
      )}
    </main>
  )
}
