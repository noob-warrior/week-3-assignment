import { Link, NavLink } from 'react-router-dom'

export default function TopNav() {
  return (
    <header className="top-nav">
      <Link className="brand-mark" to="/">
        <span className="brand-pill">Book Room</span>
        <div>
          <strong>Interactive Book Showcase</strong>
          <p>React assignment with search, favorites, and detail pages.</p>
        </div>
      </Link>
      <nav className="nav-links">
        <NavLink
          to="/"
          end
          className={({ isActive }) => `nav-link${isActive ? ' is-active' : ''}`}
        >
          Book List
        </NavLink>
        <NavLink
          to="/favorites"
          className={({ isActive }) => `nav-link${isActive ? ' is-active' : ''}`}
        >
          Favorites
        </NavLink>
      </nav>
    </header>
  )
}
