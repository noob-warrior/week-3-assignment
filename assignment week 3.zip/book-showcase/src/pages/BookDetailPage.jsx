import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import SmallButton from '../components/SmallButton'
import StateCard from '../components/StateCard'
import { fetchBookById, stripHtml } from '../utils/api'

export default function BookDetailPage({ favoriteIds, onToggleFavorite }) {
  const { id } = useParams()
  const [book, setBook] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let isMounted = true

    async function loadBook() {
      try {
        setLoading(true)
        setError('')
        const nextBook = await fetchBookById(id)
        if (isMounted) setBook(nextBook)
      } catch (fetchError) {
        if (isMounted) {
          setError(fetchError.message || 'Something went wrong while loading the book.')
        }
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    loadBook()

    return () => {
      isMounted = false
    }
  }, [id])

  if (loading) {
    return (
      <main className="page-shell">
        <StateCard title="Loading…" message="Pulling the selected book from the API." />
      </main>
    )
  }

  if (error || !book) {
    return (
      <main className="page-shell">
        <StateCard
          title="Book not available"
          message={error || 'The book could not be found.'}
          tone="error"
        />
      </main>
    )
  }

  const isFavorite = favoriteIds.includes(book.id)

  return (
    <main className="page-shell">
      <section className="detail-card">
        <div className="detail-cover-wrap">
          <img className="detail-cover" src={book.cover} alt={`${book.title} cover`} />
        </div>

        <div className="detail-copy">
          <p className="eyebrow">Book Detail Page</p>
          <h1>{book.title}</h1>
          <p className="detail-authors">
            {book.authors.length ? book.authors.join(', ') : 'Author not listed'}
          </p>

          <div className="detail-buttons">
            <SmallButton onClick={() => onToggleFavorite(book.id)} active={isFavorite}>
              {isFavorite ? 'Remove Favorite' : 'Add to Favorites'}
            </SmallButton>
            <Link className="ghost-link" to="/favorites">
              View Favorites
            </Link>
          </div>

          <div className="detail-meta">
            <div>
              <span>Publisher</span>
              <strong>{book.publisher}</strong>
            </div>
            <div>
              <span>Published</span>
              <strong>{book.publishedDate}</strong>
            </div>
            <div>
              <span>Pages</span>
              <strong>{book.pageCount}</strong>
            </div>
            <div>
              <span>Categories</span>
              <strong>{book.categories.length ? book.categories.join(', ') : 'Not listed'}</strong>
            </div>
          </div>

          <section className="description-box">
            <h2>About this book</h2>
            <p>{stripHtml(book.description)}</p>
          </section>
        </div>
      </section>
    </main>
  )
}
