export default function SmallButton({ children, onClick, active, type = 'button' }) {
  return (
    <button
      type={type}
      className={`small-button${active ? ' is-active' : ''}`}
      onClick={onClick}
    >
      {children}
    </button>
  )
}
