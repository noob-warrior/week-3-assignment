import { useState, useEffect } from 'react'
import BookCard from '../components/BookCard'
import StateCard from '../components/StateCard'
import { fetchGoogleBooks, fetchOpenLibraryBooks } from '../utils/api'

function SearchBar({ query, onChange, totalCount, visibleCount, sourceNote }) {
  return (
    <section className="search-panel">
      <div>
        <p className="eyebrow">Book List Page</p>
        <h1>Browse a stack of books and narrow them down with search.</h1>
        <p className="muted-copy">
          Books are loaded from the Google Books API when the page mounts. Filter by title or
          author in real time.
        </p>
        {sourceNote && <p className="source-note">{sourceNote}</p>}
      </div>
      <div className="search-side">
        <label className="search-label" htmlFor="book-search">
          Search by title or author
        </label>
        <input
          id="book-search"
          className="search-input"
          type="text"
          value={query}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Try Harry Potter, Tolkien, mystery…"
        />
        <p className="search-note">
          Showing {visibleCount} of {totalCount} books
        </p>
      </div>
    </section>
  )
}

export default function HomePage({ favoriteIds, onToggleFavorite }) {
  const [books, setBooks] = useState([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [sourceNote, setSourceNote] = useState('')

  useEffect(() => {
    let isMounted = true

    async function loadBooks() {
      try {
        setLoading(true)
        setError('')
        setSourceNote('')

        try {
          const nextBooks = await fetchGoogleBooks()
          if (isMounted) setBooks(nextBooks)
        } catch {
          // Fallback to Open Library if Google Books fails
          const nextBooks = await fetchOpenLibraryBooks()
          if (isMounted) {
            setBooks(nextBooks)
            setSourceNote('Google Books was busy, so the app switched to Open Library.')
          }
        }
      } catch (fetchError) {
        if (isMounted) {
          setError(fetchError.message || 'Something went wrong while loading the books.')
        }
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    loadBooks()

    return () => {
      isMounted = false
    }
  }, [])

  const cleanQuery = query.trim().toLowerCase()
  const filteredBooks = cleanQuery
    ? books.filter(
        (book) =>
          book.title.toLowerCase().includes(cleanQuery) ||
          book.authors.join(' ').toLowerCase().includes(cleanQuery)
      )
    : books

  return (
    <main className="page-shell">
      <SearchBar
        query={query}
        onChange={setQuery}
        totalCount={books.length}
        visibleCount={filteredBooks.length}
        sourceNote={sourceNote}
      />

      {loading && <StateCard title="Loading…" message="Fetching books from the API." />}

      {!loading && error && (
        <StateCard title="Could not load books" message={error} tone="error" />
      )}

      {!loading && !error && filteredBooks.length === 0 && (
        <StateCard
          title="No matches"
          message="Nothing matched that search. Try another title or author."
        />
      )}

      {!loading && !error && filteredBooks.length > 0 && (
        <section className="book-grid">
          {filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              isFavorite={favoriteIds.includes(book.id)}
              onToggleFavorite={onToggleFavorite}
            />
          ))}
        </section>
      )}
    </main>
  )
}
