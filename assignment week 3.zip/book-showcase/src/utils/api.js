const GOOGLE_API_BASE = 'https://www.googleapis.com/books/v1/volumes'
const OPEN_LIBRARY_BASE = 'https://openlibrary.org'
const OPEN_LIBRARY_SEARCH = OPEN_LIBRARY_BASE + '/search.json'
const DEFAULT_COVER = 'https://via.placeholder.com/160x230?text=No+Cover'

// ── ID helpers ──────────────────────────────────────────────────────────────

export function makeBookId(source, rawId) {
  return source + '__' + encodeURIComponent(rawId)
}

export function parseBookId(bookId) {
  const divider = bookId.indexOf('__')
  if (divider === -1) return { source: 'google', rawId: bookId }
  return {
    source: bookId.slice(0, divider),
    rawId: decodeURIComponent(bookId.slice(divider + 2)),
  }
}

// ── Normalisers ──────────────────────────────────────────────────────────────

export function normalizeGoogleBook(item) {
  const info = item.volumeInfo ?? {}
  const imageLinks = info.imageLinks ?? {}
  return {
    id: makeBookId('google', item.id),
    title: info.title ?? 'Untitled',
    authors: info.authors ?? [],
    description: info.description ?? 'No description was provided for this book.',
    cover: imageLinks.thumbnail ?? imageLinks.smallThumbnail ?? DEFAULT_COVER,
    categories: info.categories ?? [],
    publisher: info.publisher ?? 'Unknown publisher',
    publishedDate: info.publishedDate ?? 'Unknown date',
    pageCount: info.pageCount ?? 'Not listed',
  }
}

export function normalizeOpenLibrarySearchBook(item) {
  return {
    id: makeBookId('open', item.key),
    title: item.title ?? 'Untitled',
    authors: item.author_name ?? [],
    description: 'Open the detail page to see more about this book.',
    cover: item.cover_i
      ? `https://covers.openlibrary.org/b/id/${item.cover_i}-L.jpg`
      : DEFAULT_COVER,
    categories: (item.subject ?? []).slice(0, 3),
    publisher: item.publisher?.[0] ?? 'Unknown publisher',
    publishedDate: item.first_publish_year ? String(item.first_publish_year) : 'Unknown date',
    pageCount: item.number_of_pages_median ?? 'Not listed',
  }
}

export function normalizeOpenLibraryDetailBook(item, authors) {
  let description = 'No description was provided for this book.'
  if (typeof item.description === 'string') description = item.description
  else if (item.description?.value) description = item.description.value

  return {
    id: makeBookId('open', item.key),
    title: item.title ?? 'Untitled',
    authors: authors ?? [],
    description,
    cover:
      Array.isArray(item.covers) && item.covers.length > 0
        ? `https://covers.openlibrary.org/b/id/${item.covers[0]}-L.jpg`
        : DEFAULT_COVER,
    categories: (item.subjects ?? []).slice(0, 4),
    publisher: 'Open Library',
    publishedDate: item.first_publish_date ?? 'Unknown date',
    pageCount: item.number_of_pages ?? 'Not listed',
  }
}

// ── Fetchers ─────────────────────────────────────────────────────────────────

export async function fetchGoogleBooks() {
  const response = await fetch(
    `${GOOGLE_API_BASE}?q=subject:fiction&maxResults=24&printType=books`
  )
  if (!response.ok) throw new Error('Google Books is not responding right now.')
  const data = await response.json()
  return (data.items ?? []).map(normalizeGoogleBook)
}

export async function fetchOpenLibraryBooks() {
  const response = await fetch(`${OPEN_LIBRARY_SEARCH}?q=fiction&limit=24`)
  if (!response.ok) throw new Error('Open Library is not responding right now.')
  const data = await response.json()
  return (data.docs ?? [])
    .filter((item) => item.key)
    .slice(0, 24)
    .map(normalizeOpenLibrarySearchBook)
}

export async function fetchGoogleBookById(rawId) {
  const response = await fetch(`${GOOGLE_API_BASE}/${rawId}`)
  if (!response.ok) throw new Error('Could not fetch that book.')
  const data = await response.json()
  return normalizeGoogleBook(data)
}

export async function fetchOpenLibraryBookById(rawId) {
  const response = await fetch(`${OPEN_LIBRARY_BASE}${rawId}.json`)
  if (!response.ok) throw new Error('Could not fetch that book.')
  const data = await response.json()

  const authorNames = await Promise.all(
    (data.authors ?? []).slice(0, 4).map(async (authorItem) => {
      const key = authorItem?.author?.key
      if (!key) return null
      try {
        const res = await fetch(`${OPEN_LIBRARY_BASE}${key}.json`)
        if (!res.ok) return null
        const a = await res.json()
        return a.name ?? null
      } catch {
        return null
      }
    })
  )

  return normalizeOpenLibraryDetailBook(data, authorNames.filter(Boolean))
}

export function fetchBookById(bookId) {
  const { source, rawId } = parseBookId(bookId)
  return source === 'open' ? fetchOpenLibraryBookById(rawId) : fetchGoogleBookById(rawId)
}

// ── localStorage helpers ──────────────────────────────────────────────────────

export const FAVORITES_KEY = 'assignment3.favoriteBooks'

export function readFavoriteIds() {
  try {
    const raw = window.localStorage.getItem(FAVORITES_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function stripHtml(value) {
  const temp = document.createElement('div')
  temp.innerHTML = value ?? ''
  return temp.textContent || temp.innerText || ''
}
